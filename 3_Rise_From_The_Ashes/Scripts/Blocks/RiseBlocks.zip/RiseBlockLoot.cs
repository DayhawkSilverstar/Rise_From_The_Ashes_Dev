﻿using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.Scripting;

public class RiseBlockLoot : BlockLoot
{   
    private new readonly BlockActivationCommand[] cmds =
    {
        new BlockActivationCommand("Search", "search",_enabled: false),        
        new BlockActivationCommand("Take", "hand",_enabled: false)
    };

    private float TakeDelay = 0;
    private float AllowPickup = 0;

    // PERFORMANCE: Debouncing for ForceChunkRegeneration - PER INSTANCE not static
    private float lastRegenTime = 0f;
    private const float REGEN_COOLDOWN = 0.1f; // 100ms between forced chunk regens

    public RiseBlockLoot()
    {
        HasTileEntity = true;
    }

    public override void Init()
    {
        base.Init();

        TakeDelay = 2f;
        Properties.ParseFloat("AllowPickup", ref AllowPickup);
        Properties.ParseFloat("TakeDelay", ref TakeDelay);
    }

    // CRITICAL FIX: Override OnBlockPlaced to ensure immediate chunk updates
    public override BlockValue OnBlockPlaced(WorldBase _world, int _clrIdx, Vector3i _blockPos, BlockValue _blockValue, GameRandom _rnd)
    {
        Log.Out("RiseBlockLoot - OnBlockPlaced at " + _blockPos.ToString());
        
        // Call base implementation first
        BlockValue result = base.OnBlockPlaced(_world, _clrIdx, _blockPos, _blockValue, _rnd);
        
        // CRITICAL FIX: Force immediate chunk regeneration for network sync
        ForceChunkRegeneration(_world, _clrIdx, _blockPos);
        
        Log.Out("RiseBlockLoot - Block placement processed and chunk regeneration forced at " + _blockPos.ToString());
        
        return result;
    }

    // CRITICAL FIX: Override PlaceBlock to ensure proper network synchronization
    public override void PlaceBlock(WorldBase _world, BlockPlacement.Result _result, EntityAlive _ea)
    {
        Log.Out("RiseBlockLoot - PlaceBlock at " + _result.blockPos.ToString());
        
        // Call base implementation which handles chunk updates automatically
        base.PlaceBlock(_world, _result, _ea);
        
        // CRITICAL FIX: Force immediate chunk regeneration for network sync
        ForceChunkRegeneration(_world, _result.clrIdx, _result.blockPos);
        
        Log.Out("RiseBlockLoot - Block placed and chunk regeneration forced at " + _result.blockPos.ToString());
    }

    /// <summary>
    /// CRITICAL FIX: Forces immediate chunk regeneration for network synchronization
    /// This ensures that when acting as host, chunk updates are sent to clients without delay
    /// PERFORMANCE: Includes debouncing to prevent excessive chunk regeneration during rapid placements
    /// NETWORKING FIX: Uses correct cluster index instead of always Cluster0
    /// </summary>
    /// <param name="_world">The world instance</param>
    /// <param name="_clrIdx">The cluster index - CRITICAL for multiplayer</param>
    /// <param name="_blockPos">The block position that was modified</param>
    private void ForceChunkRegeneration(WorldBase _world, int _clrIdx, Vector3i _blockPos)
    {
        try
        {
            // PERFORMANCE: Debounce rapid chunk regeneration calls (per-instance, not static)
            float currentTime = Time.time;
            if (currentTime - lastRegenTime < REGEN_COOLDOWN)
            {
                // Skip forced regen if called too frequently - rely on normal batching
                Log.Out($"RiseBlockLoot - Skipping chunk regen (debounced) at {_blockPos}, last regen was {(currentTime - lastRegenTime) * 1000:F1}ms ago");
                return;
            }
            
            lastRegenTime = currentTime;
            
            World world = _world as World;
            if (world == null)
            {
                Log.Warning($"RiseBlockLoot - WorldBase is not a World instance, cannot force chunk regeneration");
                return;
            }
            
            int chunkX = World.toChunkXZ(_blockPos.x);
            int chunkZ = World.toChunkXZ(_blockPos.z);
            
            // NETWORKING FIX: Use the correct cluster index passed as parameter
            ChunkCluster chunkCluster = null;
            
            if (world.ChunkClusters != null && _clrIdx >= 0 && _clrIdx < world.ChunkClusters.Count)
            {
                chunkCluster = world.ChunkClusters[_clrIdx];
            }
            
            if (chunkCluster == null)
            {
                chunkCluster = world.ChunkCache.ChunkProvider as ChunkCluster;
            }
            
            if (chunkCluster != null)
            {
                Chunk chunk = (Chunk)chunkCluster.GetChunkSync(chunkX, chunkZ);
                if (chunk != null)
                {
                    chunkCluster.ChunkPosNeedsRegeneration_DelayedStart();
                    chunkCluster.chunkPosNeedsRegeneration(chunk, _blockPos.x, _blockPos.y, _blockPos.z, true);
                    chunkCluster.ChunkPosNeedsRegeneration_DelayedStop();
                    
                    Log.Out($"RiseBlockLoot - Forced chunk regeneration at chunk ({chunkX}, {chunkZ}) for block {_blockPos} in cluster {_clrIdx}");
                }
                else
                {
                    Log.Warning($"RiseBlockLoot - Chunk not found at ({chunkX}, {chunkZ}) for block {_blockPos}");
                }
            }
            else
            {
                Log.Warning($"RiseBlockLoot - ChunkCluster not available for forcing regeneration at index {_clrIdx} (ChunkProvider type: {world.ChunkCache.ChunkProvider?.GetType().Name ?? "null"})");
            }
        }
        catch (Exception ex)
        {
            Log.Error($"RiseBlockLoot - Error forcing chunk regeneration: {ex.Message}");
            Log.Exception(ex);
        }
    }

    public override bool OnBlockActivated(string _commandName, WorldBase _world, int _cIdx, Vector3i _blockPos, BlockValue _blockValue, EntityPlayerLocal _player)
    {
        // CRITICAL FIX: Handle child blocks like base game does
        if (_blockValue.ischild)
        {
            Vector3i parentPos = _blockValue.Block.multiBlockPos.GetParentPos(_blockPos, _blockValue);
            BlockValue block = _world.GetBlock(parentPos);
            return OnBlockActivated(_commandName, _world, _cIdx, parentPos, block, _player);
        }

        Log.Out("RiseBlockLoot - OnBlockActivated");

        try
        {
            switch (_commandName)
            {
                case "Take":
                    Log.Out("RiseBlockLoot - Trying to pick up a block.");
                    TakeItemWithTimer(_cIdx, _blockPos, _blockValue, _player);
                    return true;
                case "Search":  
                    Log.Out("RiseBlockLoot - Trying to loot a loot block.");
                    TileEntityLootContainer tileEntityLootContainer = _world.GetTileEntity(_cIdx, _blockPos) as TileEntityLootContainer;
                    if (tileEntityLootContainer != null)
                    {
                        if (!tileEntityLootContainer.bWasTouched)
                        {
                            _player.SetCVar(".lootedContainer", 1f);
                        }
                    }
                    Log.Out("RiseBlockLoot - Command:" + _commandName);
                    base.OnBlockActivated(_commandName, _world, _cIdx, _blockPos, _blockValue, _player);
                    return true;
            }
        }
        catch (Exception e)
        { 
                Log.Out("RiseBlockLoot - Exception in OnBlockActivated: {0}", e);
        }

        return false;
    }


    public override BlockActivationCommand[] GetBlockActivationCommands(WorldBase _world, BlockValue _blockValue, int _clrIdx, Vector3i _blockPos, EntityAlive _entityFocusing)
    {
        cmds[0].enabled = true;        
        cmds[1].enabled = TakeDelay > 0f;
        return cmds;
    }

    public void TakeItemWithTimer(int _cIdx, Vector3i _blockPos, BlockValue _blockValue, EntityAlive _player)
    {
        #region TakeItemWithTimer
        Log.Out("Trying to pick up a block.");
        if (_blockValue.damage > 0)
        {
            GameManager.ShowTooltip(_player as EntityPlayerLocal, Localization.Get("ttRepairBeforePickup"), string.Empty, "ui_denied");
            return;
        }

        LocalPlayerUI playerUI = (_player as EntityPlayerLocal).PlayerUI;
        playerUI.windowManager.Open("timer", _bModal: true);
        XUiC_Timer childByType = playerUI.xui.GetChildByType<XUiC_Timer>();
        TimerEventData timerEventData = new TimerEventData();
        timerEventData.Data = new object[4] { _cIdx, _blockValue, _blockPos, _player };
        timerEventData.Event += EventData_Event;
        childByType.SetTimer(TakeDelay, timerEventData);

        #endregion
    }

    private void EventData_Event(TimerEventData timerData)
    {
        #region EventData_Event
        Log.Out($"EventData");
        var world = GameManager.Instance.World;

        var array = (object[])timerData.Data;
        var clrIdx = (int)array[0];
        var blockValue = (BlockValue)array[1];
        var vector3i = (Vector3i)array[2];
        var block = world.GetBlock(vector3i);
        var entityPlayerLocal = array[3] as EntityPlayerLocal;

        // Pick up the item and put it in your inventory.
        var uiforPlayer = LocalPlayerUI.GetUIForPlayer(entityPlayerLocal);
        var itemStack = new ItemStack(block.ToItemValue(), 1);
        if (!uiforPlayer.xui.PlayerInventory.AddItem(itemStack, true))
            uiforPlayer.xui.PlayerInventory.DropItem(itemStack);
        
        // CRITICAL FIX: SetBlockRPC handles chunk updates and synchronization automatically  
        world.SetBlockRPC(clrIdx, vector3i, BlockValue.Air);
        
        Log.Out("RiseBlockLoot - Block picked up and world updated at " + vector3i.ToString());

        #endregion
    }
}
