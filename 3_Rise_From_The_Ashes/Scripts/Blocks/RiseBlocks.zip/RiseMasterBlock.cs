﻿using HarmonyLib;
using Platform;
using System;
using UnityEngine;

public class RiseMasterBlock : Block
{
    public static string PropDamageResist = "DamageResist";

    private readonly BlockActivationCommand[] cmds =
    {
        new BlockActivationCommand("search", "search", false),
        new BlockActivationCommand("take", "hand", false)
    };

    private float TakeDelay = 0;
    private float AllowPickup = 0;
    private bool LootContainer = false;

    EntityPlayer localPlayer;

    // PERFORMANCE: Debouncing for ForceChunkRegeneration - PER INSTANCE not static
    private float lastRegenTime = 0f;
    private const float REGEN_COOLDOWN = 0.1f; // 100ms between forced chunk regens

    public RiseMasterBlock()
    {
        HasTileEntity = true;
    }

    public override void Init()
    {
        base.Init();

        TakeDelay = 2f;
        Properties.ParseFloat("AllowPickup", ref AllowPickup);
        Properties.ParseFloat("TakeDelay", ref TakeDelay);
        Properties.ParseBool("LootContainer", ref LootContainer);
        IsNotifyOnLoadUnload = true;
    }

    // Only fires if IsNotifyOnLoadUnload is set to true
    public override void OnBlockLoaded(WorldBase _world, int _clrIdx, Vector3i _blockPos, BlockValue _blockValue)
    {
        base.OnBlockLoaded(_world, _clrIdx, _blockPos, _blockValue);
    }

    // Only fires if IsNotifyOnLoadUnload is set to true
    public override void OnBlockUnloaded(WorldBase _world, int _clrIdx, Vector3i _blockPos, BlockValue _blockValue)
    {
        base.OnBlockUnloaded(_world, _clrIdx, _blockPos, _blockValue);
    }

    // Display custom messages for turning on and off the music box, based on the block's name.
    public override string GetActivationText(WorldBase _world, BlockValue _blockValue, int _clrIdx, Vector3i _blockPos,
        EntityAlive _entityFocusing)
    {
        #region GetActivationText
        return base.GetActivationText(_world, _blockValue, _clrIdx,_blockPos, _entityFocusing);
        #endregion
    }

    public override int OnBlockDamaged(WorldBase _world, int _clrIdx, Vector3i _blockPos, BlockValue _blockValue, int _damagePoints, int _entityIdThatDamaged, ItemActionAttack.AttackHitInfo _attackHitInfo, bool _bUseHarvestTool, bool _bBypassMaxDamage, int _recDepth = 0)
    {
        // Code for hardness inserted here.      
        int damage = _blockValue.damage;
        int num = damage + _damagePoints;
        int initialDamage = _damagePoints;
        int finalDamage = 0;
        UInt16 damageResist = 0;

        // num less than zero means it is being upgraded.
        if (num < 0)
        {
            // Determine if the player of the client is the same on doing the damage
            EntityPlayerLocal player = _world.GetPrimaryPlayer();
            Log.Out("Player ID : {0} and Damage ID : {1} ", player.entityId.ToString(), _entityIdThatDamaged.ToString());
            if (player.entityId == _entityIdThatDamaged)
            {
                BlockValue newBlock = _blockValue;

                foreach (SItemNameCount item in newBlock.Block.RepairItems)
                {
                    try
                    {
                        ItemValue itemValue = ItemClass.GetItem(item.ItemName);
                        double cnt = Math.Floor(item.Count / 2.0);
                        Log.Out("Item count : (" + cnt.ToString() + ")");
                        if (cnt == 0)
                        {
                            cnt = 1;
                        }
                        // Create an item stack containing the damaged block
                        var itemStack = new ItemStack(itemValue, (int)cnt);

                        Log.Out("Item Stack count " + itemStack.count.ToString());
                        
                        // Add it to the players inventory. 
                        if (player.bag.AddItem(itemStack))
                        {
                            Log.Out("Item added to players bag : " + item.ItemName + " (" + cnt.ToString() + ")");
                        }
                        else if (player.inventory.AddItem(itemStack))
                        {
                            Log.Out("Item added to players toolbar : " + item.ItemName + " (" + cnt.ToString() + ")");
                        }
                        else
                        {
                            Log.Out("Item dropped : " + item.ItemName + " (" + cnt.ToString() + ")");
                            _world.GetGameManager().ItemDropServer(itemStack, player.position, Vector3.zero, player.entityId, 60.0f);
                        }
                    }
                    catch (Exception ex)
                    {
                        Log.Out("Failed creating repair items");
                        Log.Out(ex.Message);
                    }
                }

                Log.Out("Player upgrades " + _blockValue.Block.GetBlockName() + " For : " + initialDamage.ToString());
                
                // CRITICAL FIX: Call base method which handles proper world updates and chunk tracking
                int result = base.OnBlockDamaged(_world, _clrIdx, _blockPos, _blockValue, initialDamage, _entityIdThatDamaged, _attackHitInfo, _bUseHarvestTool, _bBypassMaxDamage, _recDepth);
                
                // Don't force chunk regen here - base.OnBlockDamaged handles it via SetBlockRPC
                
                Log.Out("Upgrade completed - world updated at " + _blockPos.ToString());
                
                return result;
            }
        }
        else
        {
            // <property name="DamageResist" value="1"/>            

            if (Properties.Values.ContainsKey(PropDamageResist))
            {
                UInt16.TryParse(Properties.Values[PropDamageResist], out damageResist);
            }

            finalDamage = initialDamage - damageResist;
            if (finalDamage < 0)
            {
                finalDamage = 0;
            }
        }

        if (initialDamage < 0)
        {
            Log.Out("Player repairs " + _blockValue.Block.GetBlockName() + " For : " + initialDamage.ToString());
            
            // CRITICAL FIX: Let base class handle repairs properly
            int result = base.OnBlockDamaged(_world, _clrIdx, _blockPos, _blockValue, initialDamage, _entityIdThatDamaged, _attackHitInfo, _bUseHarvestTool, _bBypassMaxDamage, _recDepth);
            
            // Don't force chunk regen here - base.OnBlockDamaged handles it via SetBlockRPC
            
            Log.Out("Repair completed - world updated at " + _blockPos.ToString());
            
            return result;
        }

        EntityAlive ea = GameManager.Instance.World.GetEntity(_entityIdThatDamaged) as EntityAlive;
        if (ea != null)
        {
            ItemActionData itemActionData = ea.inventory.holdingItemData.actionData[0];
            if (itemActionData != null)
            {
                Log.Out("Weapon = " + ea.inventory.holdingItem.GetItemName());
                int maxDamage = (int)itemActionData.attackDetails.damage * 3;
                if (maxDamage < finalDamage)
                {
                    Log.Out("Final Damage :" + finalDamage.ToString() + " is greater than " + maxDamage.ToString());
                    finalDamage = maxDamage;                  
                }
            }

            if (ea.Buffs.CVars.ContainsKey("$blockDamageDone"))
            {
                Log.Out("Setting $blockDamageDone :" + finalDamage.ToString());
                ea.Buffs.CVars["$blockDamageDone"] = finalDamage;
            }
            else
            {
                Log.Out("$blockDamageDone is not found.");
            }

            Log.Out("Entity : " + ea.EntityName + " Damages : " + _blockValue.Block.GetBlockName() + " For : " + finalDamage.ToString() + "(" + initialDamage.ToString() + ") damage after damage resist value of (" + damageResist.ToString() + ")");
        }  
        else
        {
            Log.Out("Entity : " + _entityIdThatDamaged.ToString() + " Damages : " + _blockValue.Block.GetBlockName() + " For : " + finalDamage.ToString() + "(" + initialDamage.ToString() + ") damage after damage resist value of (" + damageResist.ToString() + ")");
        }

        int result2 = base.OnBlockDamaged(_world, _clrIdx, _blockPos, _blockValue, finalDamage, _entityIdThatDamaged, _attackHitInfo, _bUseHarvestTool, _bBypassMaxDamage, _recDepth);

        return result2;
    }

    public override BlockActivationCommand[] GetBlockActivationCommands(WorldBase _world, BlockValue _blockValue,
        int _clrIdx, Vector3i _blockPos, EntityAlive _entityFocusing)
    {        
        if (AllowPickup > 0)
        {
            cmds[0].enabled = true;
            cmds[1].enabled = TakeDelay > 0f;
        }
        else
        {
            _blockValue.Block.CanPickup = false;
        }
        
        return cmds;
    }

    public override void OnBlockPlaceBefore(WorldBase _world, ref BlockPlacement.Result _bpResult, EntityAlive _ea, GameRandom _rnd)
    {
        base.OnBlockPlaceBefore(_world, ref _bpResult, _ea, _rnd);
    }

    // CRITICAL FIX: Override OnBlockPlaced to ensure immediate chunk updates
    public override BlockValue OnBlockPlaced(WorldBase _world, int _clrIdx, Vector3i _blockPos, BlockValue _blockValue, GameRandom _rnd)
    {
        Log.Out("RiseMasterBlock - OnBlockPlaced at " + _blockPos.ToString());
        
        // Call base implementation first - this handles chunk updates internally
        BlockValue result = base.OnBlockPlaced(_world, _clrIdx, _blockPos, _blockValue, _rnd);
        
        // CRITICAL FIX: Force immediate chunk regeneration to ensure network sync
        ForceChunkRegeneration(_world, _clrIdx, _blockPos);
        
        Log.Out("Block placement processed and chunk regeneration forced at " + _blockPos.ToString());
        
        return result;
    }

    // CRITICAL FIX: Override PlaceBlock to ensure proper server-client synchronization
    public override void PlaceBlock(WorldBase _world, BlockPlacement.Result _result, EntityAlive _ea)
    {
        Log.Out("RiseMasterBlock - PlaceBlock at " + _result.blockPos.ToString());
        
        // Call base implementation which handles the actual placement and chunk updates
        base.PlaceBlock(_world, _result, _ea);
        
        // CRITICAL FIX: Ensure chunk regeneration is queued immediately
        ForceChunkRegeneration(_world, _result.clrIdx, _result.blockPos);
        
        Log.Out("Block placed and chunk regeneration queued at " + _result.blockPos.ToString());
    }

    /// <summary>
    /// CRITICAL FIX: Forces immediate chunk regeneration for network synchronization
    /// This ensures that when acting as host, chunk updates are sent to clients without delay
    /// PERFORMANCE: Includes debouncing to prevent excessive chunk regeneration during rapid placements
    /// NETWORKING FIX: Uses correct cluster index instead of always Cluster0
    /// </summary>
    /// <param name="_world">The world instance</param>
    /// <param name="_clrIdx">The cluster index - CRITICAL for multiplayer</param>
    /// <param name="_blockPos">The block position that was modified</param>
    private void ForceChunkRegeneration(WorldBase _world, int _clrIdx, Vector3i _blockPos)
    {
        try
        {
            // PERFORMANCE: Debounce rapid chunk regeneration calls (per-instance, not static)
            float currentTime = Time.time;
            if (currentTime - lastRegenTime < REGEN_COOLDOWN)
            {
                // Skip forced regen if called too frequently - rely on normal batching
                Log.Out($"RiseMasterBlock - Skipping chunk regen (debounced) at {_blockPos}, last regen was {(currentTime - lastRegenTime) * 1000:F1}ms ago");
                return;
            }
            
            lastRegenTime = currentTime;
            
            // Get the chunk that contains this block
            World world = _world as World;
            if (world == null)
            {
                Log.Warning($"RiseMasterBlock - WorldBase is not a World instance, cannot force chunk regeneration");
                return;
            }
            
            // Convert block position to chunk position
            int chunkX = World.toChunkXZ(_blockPos.x);
            int chunkZ = World.toChunkXZ(_blockPos.z);
            
            // NETWORKING FIX: Use the correct cluster index passed as parameter
            // This is CRITICAL for dedicated servers and multiplayer
            ChunkCluster chunkCluster = null;
            
            // Try to get the specific chunk cluster for this world area
            if (world.ChunkClusters != null && _clrIdx >= 0 && _clrIdx < world.ChunkClusters.Count)
            {
                chunkCluster = world.ChunkClusters[_clrIdx];
            }
            
            // Fallback: Try direct cast if ChunkClusters not available or index invalid
            if (chunkCluster == null)
            {
                chunkCluster = world.ChunkCache.ChunkProvider as ChunkCluster;
            }
            
            if (chunkCluster != null)
            {
                // Get the specific chunk
                Chunk chunk = (Chunk)chunkCluster.GetChunkSync(chunkX, chunkZ);
                if (chunk != null)
                {
                    // Mark chunk as needing regeneration - this triggers network sync
                    chunkCluster.ChunkPosNeedsRegeneration_DelayedStart();
                    
                    // Force immediate regeneration with proper parameters
                    chunkCluster.chunkPosNeedsRegeneration(chunk, _blockPos.x, _blockPos.y, _blockPos.z, true);
                    
                    chunkCluster.ChunkPosNeedsRegeneration_DelayedStop();
                    
                    Log.Out($"RiseMasterBlock - Forced chunk regeneration at chunk ({chunkX}, {chunkZ}) for block {_blockPos} in cluster {_clrIdx}");
                }
                else
                {
                    Log.Warning($"RiseMasterBlock - Chunk not found at ({chunkX}, {chunkZ}) for block {_blockPos}");
                }
            }
            else
            {
                Log.Warning($"RiseMasterBlock - ChunkCluster not available for forcing regeneration at index {_clrIdx} (ChunkProvider type: {world.ChunkCache.ChunkProvider?.GetType().Name ?? "null"})");
            }
        }
        catch (Exception ex)
        {
            Log.Error($"RiseMasterBlock - Error forcing chunk regeneration: {ex.Message}");
            Log.Exception(ex);
        }
    }

    public override bool OnBlockActivated(string _commandName, WorldBase _world, int _cIdx, Vector3i _blockPos, BlockValue _blockValue, EntityPlayerLocal _player)
    {
        // CRITICAL FIX: Handle child blocks like base game does
        if (_blockValue.ischild)
        {
            Vector3i parentPos = _blockValue.Block.multiBlockPos.GetParentPos(_blockPos, _blockValue);
            BlockValue block = _world.GetBlock(parentPos);
            return OnBlockActivated(_commandName, _world, _cIdx, parentPos, block, _player);
        }

        Log.Out("Command : {0}", _commandName);
        if (AllowPickup > 0)
        {
            if (_commandName == "take")
            {
                Log.Out("RiseMasterBlock - Trying to pick up a block.");
                TakeItemWithTimer(_cIdx, _blockPos, _blockValue, _player);
                return true;
            }
            else if (_commandName == "search")
            {
                Log.Out("RiseMasterBlock - Trying to search.");
                Log.Out("Trigger Selected");
                return OnBlockActivated(_world, _cIdx, _blockPos, _blockValue, _player);
            }
        }

        return false;
    }

    public override bool HasBlockActivationCommands(WorldBase _world, BlockValue _blockValue, int _clrIdx, Vector3i _blockPos, EntityAlive _entityFocusing)
    {
        return true;
    }

    // We want to give the user the ability to pick up the blocks too, but the loot containers don't support that directly.
    public void TakeItemWithTimer(int _cIdx, Vector3i _blockPos, BlockValue _blockValue, EntityAlive _player)
    {
        #region TakeItemWithTimer
        Log.Out("Trying to pick up a block.");
        if (_blockValue.damage > 0)
        {
            GameManager.ShowTooltip(_player as EntityPlayerLocal, Localization.Get("ttRepairBeforePickup"), string.Empty, "ui_denied");
            return;
        }

        LocalPlayerUI playerUI = (_player as EntityPlayerLocal).PlayerUI;
        playerUI.windowManager.Open("timer", _bModal: true);
        XUiC_Timer childByType = playerUI.xui.GetChildByType<XUiC_Timer>();
        TimerEventData timerEventData = new TimerEventData();
        timerEventData.Data = new object[4] { _cIdx, _blockValue, _blockPos, _player };
        timerEventData.Event += EventData_Event;
        childByType.SetTimer(TakeDelay, timerEventData);

        #endregion
    }

    // Handles what happens to the contents of the box when you pick up the block.
    private void EventData_Event(TimerEventData timerData)
    {
        #region EventData_Event

        var world = GameManager.Instance.World;

        var array = (object[])timerData.Data;
        var clrIdx = (int)array[0];
        var blockValue = (BlockValue)array[1];
        var vector3i = (Vector3i)array[2];
        var block = world.GetBlock(vector3i);
        var entityPlayerLocal = array[3] as EntityPlayerLocal;

        // Pick up the item and put it in your inventory.
        var uiforPlayer = LocalPlayerUI.GetUIForPlayer(entityPlayerLocal);
        var itemStack = new ItemStack(block.ToItemValue(), 1);
        if (!uiforPlayer.xui.PlayerInventory.AddItem(itemStack, true))
            uiforPlayer.xui.PlayerInventory.DropItem(itemStack);
        
        // CRITICAL FIX: SetBlockRPC handles chunk updates and server-client synchronization automatically
        world.SetBlockRPC(clrIdx, vector3i, BlockValue.Air);
        
        Log.Out("Block picked up and world updated at " + vector3i.ToString());

        #endregion
    }
}

