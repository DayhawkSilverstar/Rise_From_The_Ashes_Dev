﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;


public class RisePoweredLight : BlockPoweredLight
{
    public new BlockActivationCommand[] cmds = new BlockActivationCommand[2]
    {
        new BlockActivationCommand("light", "electric_switch", _enabled: true),
        new BlockActivationCommand("take", "hand", _enabled: true)
    };

    private float TakeDelay = 0;
    private float AllowPickup = 0;
    private bool LootContainer = false;
    private bool isRuntimeSwitch;

    EntityPlayer localPlayer;

    // PERFORMANCE: Debouncing for ForceChunkRegeneration - PER INSTANCE not static
    private float lastRegenTime = 0f;
    private const float REGEN_COOLDOWN = 0.1f; // 100ms between forced chunk regens

    public RisePoweredLight()
    {
        HasTileEntity = true;
    }

    public override void Init()
    {
        base.Init();

        TakeDelay = 2f;
        Properties.ParseFloat("AllowPickup", ref AllowPickup);
        Properties.ParseFloat("TakeDelay", ref TakeDelay);
        Properties.ParseBool("LootContainer", ref LootContainer);
        IsNotifyOnLoadUnload = true;
    }

    // Only fires if IsNotifyOnLoadUnload is set to true
    public override void OnBlockLoaded(WorldBase _world, int _clrIdx, Vector3i _blockPos, BlockValue _blockValue)
    {
        base.OnBlockLoaded(_world, _clrIdx, _blockPos, _blockValue);
    }

    // Only fires if IsNotifyOnLoadUnload is set to true
    public override void OnBlockUnloaded(WorldBase _world, int _clrIdx, Vector3i _blockPos, BlockValue _blockValue)
    {
        base.OnBlockUnloaded(_world, _clrIdx, _blockPos, _blockValue);
    }

    // Display custom messages for turning on and off the music box, based on the block's name.
    public override string GetActivationText(WorldBase _world, BlockValue _blockValue, int _clrIdx, Vector3i _blockPos, EntityAlive _entityFocusing)
    {
        if (isRuntimeSwitch)
        {
            TileEntityPoweredBlock tileEntityPoweredBlock = (TileEntityPoweredBlock)_world.GetTileEntity(_clrIdx, _blockPos);
            if (tileEntityPoweredBlock != null)
            {
                PlayerActionsLocal playerInput = ((EntityPlayerLocal)_entityFocusing).playerInput;
                string arg = playerInput.Activate.GetBindingXuiMarkupString() + playerInput.PermanentActions.Activate.GetBindingXuiMarkupString();
                if (tileEntityPoweredBlock.IsToggled)
                {
                    return string.Format(Localization.Get("useSwitchLightOff"), arg);
                }

                return string.Format(Localization.Get("useSwitchLightOn"), arg);
            }
        }
        else if (_world.IsMyLandProtectedBlock(_blockPos, _world.GetGameManager().GetPersistentLocalPlayer()) && TakeDelay > 0f)
        {
            Block block = _blockValue.Block;
        }

        return null;
    }

    public override BlockActivationCommand[] GetBlockActivationCommands(WorldBase _world, BlockValue _blockValue,
        int _clrIdx, Vector3i _blockPos, EntityAlive _entityFocusing)
    {
        Log.Out("RisePoweredLight BlockComand");
        cmds[0].enabled = true;
        cmds[1].enabled = TakeDelay > 0f;
        return cmds;
    }

    public override bool OnBlockActivated(string _commandName, WorldBase _world, int _cIdx, Vector3i _blockPos, BlockValue _blockValue, EntityPlayerLocal _player)
    {
        // CRITICAL FIX: Handle child blocks like base game does
        if (_blockValue.ischild)
        {
            Vector3i parentPos = _blockValue.Block.multiBlockPos.GetParentPos(_blockPos, _blockValue);
            BlockValue block = _world.GetBlock(parentPos);
            return OnBlockActivated(_commandName, _world, _cIdx, parentPos, block, _player);
        }

        Log.Out("RisePoweredLight Command : {0}", _commandName);
        if (!(_commandName == "light"))
        {
            if (_commandName == "take")
            {
                Log.Out("RisePoweredLight - Trying to pick up a powered light block.");
                TakeItemWithTimer(_cIdx, _blockPos, _blockValue, _player);
                return true;
            }
        }
        else
        {
            TileEntityPoweredBlock tileEntityPoweredBlock = (TileEntityPoweredBlock)_world.GetTileEntity(_cIdx, _blockPos);
            if (!_world.IsEditor() && tileEntityPoweredBlock != null)
            {
                tileEntityPoweredBlock.IsToggled = !tileEntityPoweredBlock.IsToggled;
            }
        }

        return false;
    }

    public override void OnBlockPlaceBefore(WorldBase _world, ref BlockPlacement.Result _bpResult, EntityAlive _ea, GameRandom _rnd)
    {
        base.OnBlockPlaceBefore(_world, ref _bpResult, _ea, _rnd);

        localPlayer = _ea as EntityPlayer;
        Block block = _bpResult.blockValue.Block;
    }
    
    // CRITICAL FIX: Override OnBlockPlaced to ensure immediate chunk updates
    public override BlockValue OnBlockPlaced(WorldBase _world, int _clrIdx, Vector3i _blockPos, BlockValue _blockValue, GameRandom _rnd)
    {
        Log.Out("RisePoweredLight - OnBlockPlaced at " + _blockPos.ToString());
        
        // Call base implementation first
        BlockValue result = base.OnBlockPlaced(_world, _clrIdx, _blockPos, _blockValue, _rnd);
        
        // CRITICAL FIX: Force immediate chunk regeneration for network sync
        ForceChunkRegeneration(_world, _clrIdx, _blockPos);
        
        Log.Out("RisePoweredLight - Block placement processed and chunk regeneration forced at " + _blockPos.ToString());
        
        return result;
    }

    // CRITICAL FIX: Override PlaceBlock to ensure proper network synchronization
    public override void PlaceBlock(WorldBase _world, BlockPlacement.Result _result, EntityAlive _ea)
    {
        Log.Out("RisePoweredLight - PlaceBlock at " + _result.blockPos.ToString());
        
        // Call base implementation which handles chunk updates automatically
        base.PlaceBlock(_world, _result, _ea);
        
        // CRITICAL FIX: Force immediate chunk regeneration for network sync
        ForceChunkRegeneration(_world, _result.clrIdx, _result.blockPos);
        
        Log.Out("RisePoweredLight - Block placed and chunk regeneration forced at " + _result.blockPos.ToString());
    }

    /// <summary>
    /// CRITICAL FIX: Forces immediate chunk regeneration for network synchronization
    /// This ensures that when acting as host, chunk updates are sent to clients without delay
    /// PERFORMANCE: Includes debouncing to prevent excessive chunk regeneration during rapid placements
    /// NETWORKING FIX: Uses correct cluster index instead of always Cluster0
    /// </summary>
    /// <param name="_world">The world instance</param>
    /// <param name="_clrIdx">The cluster index - CRITICAL for multiplayer</param>
    /// <param name="_blockPos">The block position that was modified</param>
    private void ForceChunkRegeneration(WorldBase _world, int _clrIdx, Vector3i _blockPos)
    {
        try
        {
            // PERFORMANCE: Debounce rapid chunk regeneration calls (per-instance, not static)
            float currentTime = Time.time;
            if (currentTime - lastRegenTime < REGEN_COOLDOWN)
            {
                // Skip forced regen if called too frequently - rely on normal batching
                Log.Out($"RisePoweredLight - Skipping chunk regen (debounced) at {_blockPos}, last regen was {(currentTime - lastRegenTime) * 1000:F1}ms ago");
                return;
            }
            
            lastRegenTime = currentTime;
            
            World world = _world as World;
            if (world == null)
            {
                Log.Warning($"RisePoweredLight - WorldBase is not a World instance, cannot force chunk regeneration");
                return;
            }
            
            int chunkX = World.toChunkXZ(_blockPos.x);
            int chunkZ = World.toChunkXZ(_blockPos.z);
            
            // NETWORKING FIX: Use the correct cluster index passed as parameter
            ChunkCluster chunkCluster = null;
            
            if (world.ChunkClusters != null && _clrIdx >= 0 && _clrIdx < world.ChunkClusters.Count)
            {
                chunkCluster = world.ChunkClusters[_clrIdx];
            }
            
            if (chunkCluster == null)
            {
                chunkCluster = world.ChunkCache.ChunkProvider as ChunkCluster;
            }
            
            if (chunkCluster != null)
            {
                Chunk chunk = (Chunk)chunkCluster.GetChunkSync(chunkX, chunkZ);
                if (chunk != null)
                {
                    chunkCluster.ChunkPosNeedsRegeneration_DelayedStart();
                    chunkCluster.chunkPosNeedsRegeneration(chunk, _blockPos.x, _blockPos.y, _blockPos.z, true);
                    chunkCluster.ChunkPosNeedsRegeneration_DelayedStop();
                    
                    Log.Out($"RisePoweredLight - Forced chunk regeneration at chunk ({chunkX}, {chunkZ}) for block {_blockPos} in cluster {_clrIdx}");
                }
                else
                {
                    Log.Warning($"RisePoweredLight - Chunk not found at ({chunkX}, {chunkZ}) for block {_blockPos}");
                }
            }
            else
            {
                Log.Warning($"RisePoweredLight - ChunkCluster not available for forcing regeneration at index {_clrIdx} (ChunkProvider type: {world.ChunkCache.ChunkProvider?.GetType().Name ?? "null"})");
            }
        }
        catch (Exception ex)
        {
            Log.Error($"RisePoweredLight - Error forcing chunk regeneration: {ex.Message}");
            Log.Exception(ex);
        }
    }

    private bool updateLightState(WorldBase _world, int _cIdx, Vector3i _blockPos, BlockValue _blockValue, bool _bSwitchLight = false)
    {
        ChunkCluster chunkCluster = _world.ChunkClusters[_cIdx];
        if (chunkCluster == null)
        {
            return false;
        }

        IChunk chunkFromWorldPos = chunkCluster.GetChunkFromWorldPos(_blockPos);
        if (chunkFromWorldPos == null)
        {
            return false;
        }

        BlockEntityData blockEntity = chunkFromWorldPos.GetBlockEntity(_blockPos);
        if (blockEntity == null || !blockEntity.bHasTransform)
        {
            return false;
        }

        bool flag = (_blockValue.meta & 2) != 0;
        if (_world.GetTileEntity(_cIdx, _blockPos) is TileEntityPoweredBlock tileEntityPoweredBlock)
        {
            flag = flag && tileEntityPoweredBlock.IsToggled;
        }

        if (_bSwitchLight)
        {
            flag = !flag;
            _blockValue.meta = (byte)((_blockValue.meta & 0xFFFFFFFDu) | (flag ? 2u : 0u));
            
            // CRITICAL FIX: SetBlockRPC handles chunk updates and synchronization automatically
            _world.SetBlockRPC(_cIdx, _blockPos, _blockValue);
            
            Log.Out("RisePoweredLight - Light state changed at " + _blockPos.ToString());
        }

        Transform transform = blockEntity.transform.Find("MainLight");
        if ((bool)transform)
        {
            LightLOD component = transform.GetComponent<LightLOD>();
            if ((bool)component)
            {
                component.SwitchOnOff(flag);
            }
        }

        transform = blockEntity.transform.Find("Point light");
        if (transform != null)
        {
            LightLOD component2 = transform.GetComponent<LightLOD>();
            if (component2 != null)
            {
                component2.SwitchOnOff(flag);
            }
        }

        return true;
    }

    public void TakeItemWithTimer(int _cIdx, Vector3i _blockPos, BlockValue _blockValue, EntityAlive _player)
    {
        #region TakeItemWithTimer
        Log.Out("RisePoweredLight - Trying to pick up a block.");
        if (_blockValue.damage > 0)
        {
            GameManager.ShowTooltip(_player as EntityPlayerLocal, Localization.Get("ttRepairBeforePickup"), string.Empty, "ui_denied");
            return;
        }

        LocalPlayerUI playerUI = (_player as EntityPlayerLocal).PlayerUI;
        playerUI.windowManager.Open("timer", _bModal: true);
        XUiC_Timer childByType = playerUI.xui.GetChildByType<XUiC_Timer>();
        TimerEventData timerEventData = new TimerEventData();
        timerEventData.Data = new object[4] { _cIdx, _blockValue, _blockPos, _player };
        timerEventData.Event += EventData_Event;
        childByType.SetTimer(TakeDelay, timerEventData);
        #endregion
    }

    // Handles what happens to the contents of the box when you pick up the block.
    private void EventData_Event(TimerEventData timerData)
    {
        #region EventData_Event

        var world = GameManager.Instance.World;

        var array = (object[])timerData.Data;
        var clrIdx = (int)array[0];
        var blockValue = (BlockValue)array[1];
        var vector3i = (Vector3i)array[2];
        var block = world.GetBlock(vector3i);
        var entityPlayerLocal = array[3] as EntityPlayerLocal;

        // Pick up the item and put it in your inventory.
        var uiforPlayer = LocalPlayerUI.GetUIForPlayer(entityPlayerLocal);
        var itemStack = new ItemStack(block.ToItemValue(), 1);
        if (!uiforPlayer.xui.PlayerInventory.AddItem(itemStack, true))
            uiforPlayer.xui.PlayerInventory.DropItem(itemStack);
        
        // CRITICAL FIX: SetBlockRPC handles chunk updates and synchronization automatically
        world.SetBlockRPC(clrIdx, vector3i, BlockValue.Air);
        
        Log.Out("RisePoweredLight - Block picked up and world updated at " + vector3i.ToString());

        #endregion
    }
}
